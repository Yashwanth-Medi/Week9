function form() {
    const name = document.getElementById("first").value;
    const email = document.getElementById("email").value;
    const rate = document.getElementById("rate").value;
	const where = document.getElementById("where").value;
   
    console.log(rate);
    if (name === "") {
        alert("Name mandatory");
        return false;
    }
    else if(email === ""){
        alert("Fill the filed of email @ mandatory .");
        return false;
    }
    else if(rate === ""){
        alert("Should not be empty");
        return false;
    }
   else if(where === ""){
        alert("ehere did it happen");
        return false;
    }
}